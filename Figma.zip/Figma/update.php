<?php

require 'function.php';

//ambil data di url
$id = $_GET["id"];

$login = query("SELECT * FROM masuk WHERE id = $id")[0];

//cek apakah tombol sumbit sudah ditekan atau belum
if( isset($_POST["login"]) ) {
 
    //cek apakah data berhasil diubah atau tidak
    if( edit($_POST) > 0 ) {
        echo 
        "<script> 
        alert('data berhasil diedit'); 
        document.location.href = 'profile.php';
        </script>";
    } else {
        echo 
        "<script> 
        alert('data gagal diedit'); 
        document.location.href = 'profile.php';
        </script>";
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <title>Update Profile</title>
    <link rel="stylesheet" href="atribut/css.css">
    
</head>
<style>
        .box{
    width: 500px;
    background: #a0ced9;
    margin: 80px auto;
    padding: 30px 30px;
}

        .kotak {
    box-sizing: border-box;
    width: 200px;
    padding: 5px;
    font-size: 11pt;
}
        
        .tombol_login {
    background-color: rgb(10, 10, 10);
    color: rgb(253, 250, 250);
    width: 128px;
    border: none;
    font-size: 11pt;
    border-radius: 3px;
    padding: 10px 20px;
    cursor: pointer;
}
    </style>
<body>
<div class="box">
        <form action="" method="POST" name="input"> 
            <input type="hidden" name="id" value="<?= $login["id"]; ?>">
            <table>
                <center><h1><b>UPDATE</b></h1><hr>
                <label for="Username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="Username" required value="<?= $login["Username"];?>"><br>

    <label for="Email"><b>Email</b></label> 
    <input type="text" placeholder="Enter Email" name="Email" required value="<?= $login["Email"];?>"> <br>
       <label for="Password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="Password" require value="<?= $login["Password"];?>">
    
            </table></center>
            <div style="text-indent: 190px;"><input type="submit" name="login" value="Update" class="tombol_login"></div>
        </form>   
        </div> 
    
</body>
</html>