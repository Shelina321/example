<?php
$conn = mysqli_connect("localhost", "root", "", "figma");

function query($query){
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while( $row = mysqli_fetch_assoc($result) ){
        $rows[] = $row;
    }
    return $rows;
}


function tambah($data){
    global $conn;
    $Username = htmlspecialchars($data["Username"]);
    $Email = htmlspecialchars($data["Email"]);
    $Password = htmlspecialchars($data["Password"]);
    
    $query = "INSERT INTO masuk VALUES('','$Username', '$Email', $Password')";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

function delete($data) {
    global $conn;
    mysqli_query($conn, "DELETE FROM masuk WHERE id = '$data'");
    return mysqli_affected_rows($conn);

}

function edit($data){
    global $conn;
    $id = htmlspecialchars($data["id"]);
    $Username = htmlspecialchars($data["Username"]);
    $Email = htmlspecialchars($data["Email"]);
    $Password = htmlspecialchars($data["Password"]);
        if($Password == "mangabest"){
        echo "<script> alert('password benar!'); </script>";
        } else {
        echo "<script> alert('password salah!'); </script>";
        }
    $query = "UPDATE masuk SET 
                Username = '$Username',
                 Email = '$Email',
                 Password = '$Password'
                 WHERE id = $id";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);

}
?>