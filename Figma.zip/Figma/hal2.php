<?php
$conn = mysqli_connect("localhost", "root", "", "figma");

if(isset($_POST["login"])){
    $Username = $_POST["Username"];
    $Email = $_POST["Email"];
    $Password = $_POST["Password"];
        if($Password == "mangabest"){
        echo "<script> alert('password benar!'); </script>";
        } else {
        echo "<script> alert('password salah!'); </script>";
        }
       
    $query = "INSERT INTO masuk VALUES ('', '$Username', '$Email', '$Password')";
    mysqli_query($conn, $query);
    echo"<script> alert('Login Berhasil'); </script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@2.51.6/dist/full.css" rel="stylesheet" type="text/css" />

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="atribut/css.css">
    <title>Page2</title>
    <style>
      body{
        background-color: #000000;
      }
    </style>
</head>
<body>
<!--Card-->
    <br>
    <div class="container">
      <div class="row align-items-start justify-content-center">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d7.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">The Lone Necromancer</h5>
              <a href="https://www.webtoons.com/en/fantasy/the-lone-necromancer/list?title_no=3690" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d8.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Perfect Marriage Revenge</h5>
              <a href="https://www.webtoons.com/en/romance/perfect-marriage-revenge/list?title_no=3484" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d3.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Unordinary</h5>
              <a href="https://www.webtoons.com/en/super-hero/unordinary/list?title_no=679" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
      </div>
    </div><br>

    <div class="container">
      <div class="row align-items-start justify-content-center">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d10.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">There Must Be Happy Endings</h5>
              <a href="https://www.webtoons.com/en/romance/there-must-be-happy-endings/list?title_no=3065" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d11.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Limit Breaker</h5>
              <a href="https://www.webtoons.com/en/action/limit-breaker/list?title_no=4176" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d12.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Half Ghost</h5>
              <a href="https://www.webtoons.com/en/romance/half-ghost/list?title_no=2765" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
      </div>
    </div>

<!--Wave-->
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#5000ca" fill-opacity="1" d="M0,64L0,128L102.9,128L102.9,192L205.7,192L205.7,128L308.6,128L308.6,160L411.4,160L411.4,32L514.3,32L514.3,256L617.1,256L617.1,288L720,288L720,96L822.9,96L822.9,96L925.7,96L925.7,32L1028.6,32L1028.6,224L1131.4,224L1131.4,128L1234.3,128L1234.3,0L1337.1,0L1337.1,160L1440,160L1440,320L1337.1,320L1337.1,320L1234.3,320L1234.3,320L1131.4,320L1131.4,320L1028.6,320L1028.6,320L925.7,320L925.7,320L822.9,320L822.9,320L720,320L720,320L617.1,320L617.1,320L514.3,320L514.3,320L411.4,320L411.4,320L308.6,320L308.6,320L205.7,320L205.7,320L102.9,320L102.9,320L0,320L0,320Z"></path></svg>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#000b76" fill-opacity="1" d="M0,64L0,128L102.9,128L102.9,192L205.7,192L205.7,128L308.6,128L308.6,160L411.4,160L411.4,32L514.3,32L514.3,256L617.1,256L617.1,288L720,288L720,96L822.9,96L822.9,96L925.7,96L925.7,32L1028.6,32L1028.6,224L1131.4,224L1131.4,128L1234.3,128L1234.3,0L1337.1,0L1337.1,160L1440,160L1440,0L1337.1,0L1337.1,0L1234.3,0L1234.3,0L1131.4,0L1131.4,0L1028.6,0L1028.6,0L925.7,0L925.7,0L822.9,0L822.9,0L720,0L720,0L617.1,0L617.1,0L514.3,0L514.3,0L411.4,0L411.4,0L308.6,0L308.6,0L205.7,0L205.7,0L102.9,0L102.9,0L0,0L0,0Z"></path></svg>
<!--Login-->
<form action="" method="post">
  <div class="container">
    <label for="Username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="Username" required>

    <label for="Email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="Email" required>
       <label for="Password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="Password" require />
    <div style="text-indent: ;" ><input type="submit" name="login" value="login" class="tombol_login w-100"></div>
      <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>
  <br>
<!--Pagination-->
    <nav aria-label="Page navigation example" >
  <ul class="pagination" >
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous" >
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="index.php">1</a></li>
    <li class="page-item"><a class="page-link" href="hal2.php">2</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
  </nav>
</body>
</html>