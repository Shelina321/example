
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/daisyui@2.51.6/dist/full.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="atribut/css.css">
    <title>WebCom</title>
    <style>
      body{
        background-color: #000000;
      }
    </style>
</head>
<body>
 
<!--Nav-->
      
  <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
  <div class="container-fluid">
  <div class="flex-none gap-2">
            <div class="dropdown">
                <label tabindex="0" class="btn btn-ghost btn-circle avatar">
                    <div class="w-10 rounded-full">
                        <img src="atribut/Pic/logo2.png" alt="user">
                    </div>
                </label>
                <ul tabindex="0"
                    class="mt-3 p-2 shadow menu menu-compact dropdown-content bg-base-100 rounded-box w-52">
                    <li>
                        <a href="profile.php">Profile</a>

                    </li>
                    <li><a href="hal2.php" id="button" class="button">Login</a></li>
                </ul>
            </div>
        </div>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="#page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#recomen">Recommendations</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#daily">Daily</a>
        </li>
    </ul>
    </div>
  </div>
  </nav>

<!--Carousel-->
 <section id=page>
    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
     <div class="carousel-inner" >
      <div class="carousel-item active">
      <img src="atribut/Pic/comic3.png" class="d-block w-100" alt=" ...">
    </div>
       <div class="carousel-item" >
      <img src="atribut/Pic/jilid1.jpg" class="d-block w-100" alt="...">
      
    </div>
    <div class="carousel-item">
      <img src="atribut/Pic/detective.jpg" class="d-block w-100" alt="...">
    </div>
    
   </div>
   <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
    </button>
     <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
    </div></section>
  <!--end carousel-->

<!--Recomen-->
    <section id=recomen>
    <!--Nav-->
        <nav class="navbar bg-body-tertiary bg-dark" data-bs-theme="dark"">
       <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">Recommendations</span>
          </div>
             </nav><br>
   <!--Card-->
    <div class="container">
      <div class="row align-items-start justify-content-center">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/dice.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Dice</h5>
              <p class="card-text">Dongtae's at the bottom of the barrel.When popular transfer student Taebin gives him an opportunity to change.</p>
              <a href="https://www.webtoons.com/en/fantasy/dice/list?title_no=64" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/zom.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Zomgan</h5>
              <p class="card-text">"Zomgans" half-human, half-zombie hybrids who envolved from a viral outbreak that wiped out human civilazation.</p>
              <a href="https://www.webtoons.com/en/action/zomgan/list?title_no=4785" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/mng3.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Assassin's Creed:Forgatten Temple</h5>
              <p class="card-text">Edward Kenway return to take the leap of faith in an all-new adventure.</p>
              <a href="https://www.webtoons.com/en/fantasy/assassins-creed-forgotten-temple/list?title_no=5273" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
      </div>
    </div></section><br>

<!--Daily-->
      <section id=daily>
      <!--Nav-->
        <nav class="navbar bg-body-tertiary bg-dark" data-bs-theme="dark"">
       <div class="container-fluid">
        <span class="navbar-brand mb-0 h1">Daily</span>
          </div>
             </nav><br>
      <!--Card-->
      <div class="container">
      <div class="row align-items-start justify-content-center">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d1.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">LYFE</h5>
              <a href="https://www.webtoons.com/en/challenge/lyfe/list?title_no=85646" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d2.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Let's Play</h5>
              <a href="https://www.webtoons.com/en/romance/letsplay/list?title_no=1218" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d9.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">The Druid Of Seoul Station</h5>
              <a href="https://www.webtoons.com/en/action/the-druid-of-seoul-station/list?title_no=3453" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
      </div>
    </div><br>

    <div class="container">
    <div class="row align-items-start justify-content-center">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d4.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">SAVE ME</h5>
              <a href="https://www.webtoons.com/en/drama/bts-save-me/list?title_no=1514" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d5.jpg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Get Schooled</h5>
              <a href="https://www.webtoons.com/en/drama/get-schooled/list?title_no=2684" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="atribut/pic/d6.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Lookism</h5>
              <a href="https://www.webtoons.com/en/drama/lookism/list?title_no=1049" class="btn btn-primary">Subscribe +</a>
            </div>
          </div>
        </div>
      </div>
    </div><br>
      </section>
<!--Pagination-->
    <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="index.php">1</a></li>
    <li class="page-item"><a class="page-link" href="hal2.php">2</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
      </a>
    </li>
  </ul>
  </nav>

</body>
</html>