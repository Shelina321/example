<?php

require 'function.php';

$masuk = query("SELECT * FROM masuk");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile</title>
    <style>
        body{
            background-image: url('atribut/Pic/bg2.png');
            color: #ffffff;
        }

    </style>
    <link rel="stylesheet" href="css.css">
</head>
<body><center><br>
    <h1>Profile</h1>
    <a href="index.php">Home</a>
    <br><br>
    <table border="1" cellpadding="30" cellspacing="0">
       <tr>
        <th>Action</th>
        <th>Username</th>
        <th>Email</th>
        <th>Password</th>
        </tr> 
       <?php foreach( $masuk as $row ) : ?>
       <tr>
        <td>
            <a href="update.php?id=<?= $row["id"]; ?>">Update</a> |
            <a href="delete.php?id=<?= $row["id"]; ?>" onclick="return confirm('yakin ingin menghapus data?');">delete</a>
        </td>
        <td><?= $row["Username"]; ?></td>
        <td><?= $row["Email"]; ?></td>
        <td><?= $row["Password"]; ?></td>
        </tr>
       <?php endforeach ; ?>
    </table></center>
</body>
</html>